package br.com.fiap.gs.gsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsapiApplication.class, args);
	}

}
