package br.com.fiap.gs.gsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
